"""
backtest.py - historic training.

BACKTEST: for every week of every chosen season, build the ratings using only
games BEFORE that week, predict that week's games, and score the predictions.
That's the honest test of whether the model works - it never sees the games
it's predicting.

  MAE        average miss on the margin, in points (lower is better)
  Accuracy   how often it picked the winner
  Baseline   the MAE of just guessing "home team wins by the home-field edge"
             - the model has to beat this to be worth anything

AUTO-TUNE: tries alternative values for each setting in GRIDS, one at a time,
keeping any change that lowers MAE. The result is saved to settings.json and
used from then on.

Caveats: the efficiency models are fit on every season in the database (just a
few coefficients, so leakage is tiny), and early-season weeks are hard because
the preseason priors are still placeholders.
"""
import math
from datetime import date

import numpy as np

import ratings
from app_config import CANCEL, load_settings, save_settings

GRIDS = {
    "RIDGE": [0.75, 1.5, 3.0, 6.0],
    "CONF_PULL": [0.0, 0.5, 0.8],
    "TEAM_HFA_RIDGE": [10.0, 25.0, 100.0],
    "LUCK_REGRESSION": [0.0, 0.5, 0.75, 1.0],
    "EFF_WEIGHT_ADV": [0.0, 0.25, 0.5, 0.75],
    "EFF_WEIGHT_BASIC": [0.0, 0.25, 0.5],
    "REST_VALUE": [0.0, 0.15, 0.3],
    "TRAVEL_VALUE": [0.0, 0.4, 0.8],
    "ALTITUDE_VALUE": [0.0, 0.5, 1.0],
}
DEFAULTS = {name: getattr(ratings, name) for name in GRIDS}   # captured at import time


class Cancelled(Exception):
    pass


def load_datasets(seasons):
    out = {}
    for s in seasons:
        try:
            out[s] = ratings.load_season(s)
            print(f"  {s}: {len(out[s]['games'])} games loaded")
        except ValueError as e:
            print(f"  {s}: skipped ({e})")
    if not out:
        raise ValueError("None of those seasons have data. Download them on the Setup tab first.")
    return out


def evaluate(datasets, weeks):
    abs_err, base_err, correct, decided, pairs = [], [], 0, 0, []
    for season, data in datasets.items():
        by_week = {}
        for g in data["games"]:
            if g[11] == "regular" and g[10] in weeks:
                by_week.setdefault(g[10], []).append(g)
        for w in sorted(by_week):
            if CANCEL.is_set():
                raise Cancelled()
            try:
                _, info = ratings.compute_ratings(data, through_week=w - 1)
            except ValueError:
                continue
            for g in by_week[w]:
                actual = g[5] - g[6]
                pred = ratings.predict(info, g, data)
                abs_err.append(abs(actual - pred))
                pairs.append((pred, actual))
                base_err.append(abs(actual - (0.0 if g[2] else ratings.HFA_PRIOR)))
                if actual != 0:
                    decided += 1
                    correct += (actual > 0) == (pred > 0)
    if not abs_err:
        raise ValueError("No games to evaluate for those seasons/weeks.")
    return {
        "mae": float(np.mean(abs_err)),
        "baseline_mae": float(np.mean(base_err)),
        "accuracy": correct / max(decided, 1),
        "games": len(abs_err),
        "pairs": pairs,
    }


def describe(score):
    return (f"{score['games']} games predicted | average miss {score['mae']:.2f} pts "
            f"(home-field-only baseline {score['baseline_mae']:.2f}) | "
            f"picked the winner {score['accuracy'] * 100:.1f}% of the time")


def tune(datasets, weeks, rounds=1):
    current = {name: getattr(ratings, name) for name in GRIDS}
    print("Scoring current settings...")
    best = evaluate(datasets, weeks)
    print("  start: " + describe(best))
    total = rounds * sum(len([v for v in opts if v != current[n]]) for n, opts in GRIDS.items())
    done = 0
    try:
        for r in range(rounds):
            for name, options in GRIDS.items():
                start = current[name]
                for value in options:
                    if value == start:
                        continue
                    done += 1
                    setattr(ratings, name, value)
                    score = evaluate(datasets, weeks)
                    kept = score["mae"] < best["mae"] - 0.005
                    print(f"  [{done}/{total}] {name} = {value}: miss {score['mae']:.3f}"
                          + ("  <- better, keeping" if kept else ""))
                    if kept:
                        best, current[name] = score, value
                    setattr(ratings, name, current[name])
    except Cancelled:
        print("Stopped early - keeping the best settings found so far.")
    for name, value in current.items():
        setattr(ratings, name, value)
    return current, best


def fit_calibration(pairs):
    """From (predicted, actual) margins: how much to scale predictions, and the typical miss."""
    p = np.array([x[0] for x in pairs], dtype=float)
    a = np.array([x[1] for x in pairs], dtype=float)
    slope = float(np.clip((p * a).sum() / max((p * p).sum(), 1e-9), 0.6, 1.4))
    sigma = float(np.std(a - slope * p))
    return slope, sigma


def _brier(pairs, slope, sigma):
    total, n = 0.0, 0
    for p, a in pairs:
        if a == 0:
            continue
        prob = ratings.win_probability(slope * p, sigma)
        total += (prob - (1.0 if a > 0 else 0.0)) ** 2
        n += 1
    return total / max(n, 1)


def learn(seasons):
    """
    Keep learning: re-score every game from weeks 3-14 using only earlier results, then refit
    the calibration (how much to scale margins, and the typical miss) and save it. Matchup and
    next-game predictions use it from then on. Takes about a minute; run it as results come in.
    """
    print("Loading seasons...")
    datasets = load_datasets(seasons)
    print("Re-scoring every game from weeks 3-14 using only earlier results...")
    pairs = evaluate(datasets, range(3, 15))["pairs"]
    old = ratings.get_calibration()
    slope, sigma = fit_calibration(pairs)
    b_old, b_new = _brier(pairs, old["slope"], old["sigma"]), _brier(pairs, slope, sigma)

    if slope < 0.95:
        why = "the model was overconfident, so margins are shrunk"
    elif slope > 1.05:
        why = "the model was too cautious, so margins are stretched"
    else:
        why = "margins were already well scaled"
    print(f"  Games used: {len(pairs)}")
    print(f"  Margin scale: {old['slope']:.3f} -> {slope:.3f}  ({why})")
    print(f"  Typical miss: +/-{old['sigma']:.1f} -> +/-{sigma:.1f} pts")
    print(f"  Win-probability error (Brier, lower is better): {b_old:.4f} -> {b_new:.4f}")

    settings = load_settings()
    settings["calibration"] = {"slope": slope, "sigma": sigma, "n": len(pairs), "updated": date.today().isoformat()}
    save_settings(settings)
    print("Saved. Matchup and next-game predictions now use this.")
    return {"slope": slope, "sigma": sigma, "n": len(pairs), "brier_before": b_old, "brier_after": b_new}


def save_tuned(params):
    settings = load_settings()
    settings["params"] = params
    save_settings(settings)


def reset_defaults():
    for name, value in DEFAULTS.items():
        setattr(ratings, name, value)
    settings = load_settings()
    settings.pop("params", None)
    save_settings(settings)
