"""
cfb_poll_app.py - the whole program in one window.

  Setup & Data   API key, download historic seasons, update the current one
  Train          check the efficiency models, backtest on past seasons, auto-tune settings
  Rankings       the poll for any season/week, filter FBS/FCS, export to CSV
  Matchups       predict any game, predict the next slate, learn from results
  Updates        install update packages (see updater.py)
  Settings       theme, text size, display options

Version 2 look: rounded cards, line icons, green accent. Everything is drawn with plain
tkinter - no extra libraries. The icons are rendered at startup from the stroke definitions
below, so they stay sharp at any screen scaling and recolor with the theme.

Run it directly with `python cfb_poll_app.py`, or package it as an .exe with build_exe.bat.
Long jobs run in the background so the window never freezes; the log has the details.
"""
import base64
import contextlib
import csv
import datetime
import math
import os
import queue
import sqlite3
import struct
import subprocess
import sys
import threading
import tkinter as tk
import traceback
import zlib
from tkinter import filedialog, messagebox, scrolledtext, ttk

import numpy as np
import requests

import app_config
import backtest          # imported before apply_tuned_params so defaults are captured first
import cfb_data
import cfb_stats
import efficiency
import ratings
import updater
from app_config import CANCEL, DB_PATH

app_config.apply_tuned_params()

FONT_FAMILY = "Segoe UI"
TEXT_SIZES = {"small": 9, "default": 10, "large": 12}

# Every text/background pairing below was checked for readable contrast (WCAG AA, 4.5:1).
PALETTES = {
    "dark": {
        "bg": "#0a1224", "card": "#0f1a31", "card_border": "#1d2d4d", "input": "#0b1528", "input_border": "#27395f",
        "text": "#eef3fb", "muted": "#9bb0d1", "accent": "#34d58a", "accent_fill": "#0f3a36", "accent_hover": "#15524a",
        "tab_fill": "#101c35", "tab_active": "#10332f", "chip": "#0c1730", "trough": "#1b2a47", "disabled_fill": "#0d172b",
        "select": "#1d4a7a", "select_text": "#ffffff", "odd": "#0c162b", "log_bg": "#08101f",
        "danger": "#ff7b7b", "warn": "#f5b94c",
    },
    "light": {
        "bg": "#edf2f8", "card": "#ffffff", "card_border": "#d4deec", "input": "#f5f8fc", "input_border": "#bccadf",
        "text": "#0f1c33", "muted": "#51627f", "accent": "#076f40", "accent_fill": "#def5e9", "accent_hover": "#c6ecd7",
        "tab_fill": "#ffffff", "tab_active": "#e3f6ec", "chip": "#f1f6fb", "trough": "#d9e2ef", "disabled_fill": "#f1f4f9",
        "select": "#cfe3ff", "select_text": "#0f1c33", "odd": "#f4f7fb", "log_bg": "#ffffff",
        "danger": "#b3261e", "warn": "#8a5200",
    },
}

UI_SCALE = 1.0


def S(n):
    """Scale a pixel size for high-resolution screens."""
    return int(round(n * UI_SCALE))


# ---------------- Icons: stroke definitions on a 24x24 grid, rendered with anti-aliasing ----------------
def _circle(cx, cy, r, n=32):
    return [(cx + r * math.cos(2 * math.pi * i / n), cy + r * math.sin(2 * math.pi * i / n)) for i in range(n + 1)]


def _arc(cx, cy, r, a0, a1, n=20):
    return [(cx + r * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
             cy + r * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)]


def _ellipse(cx, cy, rx, ry, rot=0, a0=0, a1=360, n=40):
    out = []
    c, s = math.cos(math.radians(rot)), math.sin(math.radians(rot))
    for i in range(n + 1):
        t = math.radians(a0 + (a1 - a0) * i / n)
        x, y = rx * math.cos(t), ry * math.sin(t)
        out.append((cx + x * c - y * s, cy + x * s + y * c))
    return out


def _rrect(x0, y0, x1, y1, r, n=6):
    pts = []
    for cx, cy, a0 in ((x1 - r, y0 + r, -90), (x1 - r, y1 - r, 0), (x0 + r, y1 - r, 90), (x0 + r, y0 + r, 180)):
        pts += _arc(cx, cy, r, a0, a0 + 90, n)
    return pts + [pts[0]]


def _gear():
    pts = []
    for i in range(8 * 4 + 1):
        ang = 2 * math.pi * i / 32
        r = 10.0 if i % 4 in (0, 1) else 7.6
        pts.append((12 + r * math.cos(ang), 12 + r * math.sin(ang)))
    return [pts, _circle(12, 12, 3.2)]


def _moon():
    outer = _arc(12, 12, 9, 5, 265, 40)
    inner = _arc(16.84, 7.16, 7, 216.5, 53.5, 30)
    return [outer + inner + [outer[0]]]


def _sun():
    rays = []
    for a in range(0, 360, 45):
        c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
        rays.append([(12 + 7.2 * c, 12 + 7.2 * s), (12 + 9.6 * c, 12 + 9.6 * s)])
    return [_circle(12, 12, 4.2)] + rays


ICONS = {
    "football": [_ellipse(12, 12, 10.5, 6.2, -35), [(8.4, 15.4), (15.6, 8.6)], [(10.5, 10.0), (13.5, 13.0)],
                 [(9.6, 12.6), (11.6, 14.6)], [(12.4, 9.4), (14.4, 11.4)]],
    "gear": _gear(),
    "dumbbell": [[(7, 12), (17, 12)], _rrect(3.5, 7, 7, 17, 1.2), _rrect(17, 7, 20.5, 17, 1.2),
                 [(1.5, 10), (1.5, 14)], [(22.5, 10), (22.5, 14)]],
    "trophy": [[(7.5, 4), (16.5, 4), (16.5, 10), (14.5, 13.5), (12, 14.5), (9.5, 13.5), (7.5, 10), (7.5, 4)],
               [(7.5, 6), (4.2, 6), (4.2, 8.5), (7.6, 10.4)], [(16.5, 6), (19.8, 6), (19.8, 8.5), (16.4, 10.4)],
               [(12, 14.5), (12, 18)], [(8, 20.5), (16, 20.5)], [(9.5, 18), (14.5, 18)]],
    "shuffle": [[(16, 3), (21, 3), (21, 8)], [(4, 20), (21, 3)], [(21, 16), (21, 21), (16, 21)],
                [(15, 15), (21, 21)], [(4, 4), (9, 9)]],
    "refresh": [_arc(12, 12, 8.5, 200, 340, 18), [(17.5, 2.8), (18.6, 6.4), (15, 7.2)],
                _arc(12, 12, 8.5, 20, 160, 18), [(6.5, 21.2), (5.4, 17.6), (9, 16.8)]],
    "key": [_circle(7.3, 16.7, 4.3), [(10.4, 13.6), (21, 3)], [(16.6, 7.4), (19.6, 10.4)], [(18.8, 5.2), (21.2, 7.6)]],
    "calendar": [_rrect(3, 5, 21, 21, 2.6), [(3, 10.2), (21, 10.2)], [(8, 3), (8, 7)], [(16, 3), (16, 7)],
                 [(8, 14), (8.1, 14)], [(12, 14), (12.1, 14)], [(16, 14), (16.1, 14)],
                 [(8, 17.4), (8.1, 17.4)], [(12, 17.4), (12.1, 17.4)]],
    "database": [_ellipse(12, 5.5, 8.5, 3), [(3.5, 5.5), (3.5, 18.5)], [(20.5, 5.5), (20.5, 18.5)],
                 _ellipse(12, 12, 8.5, 3, 0, 0, 180, 24), _ellipse(12, 18.5, 8.5, 3, 0, 0, 180, 24)],
    "download": [[(4, 15), (4, 20), (20, 20), (20, 15)], [(12, 3.5), (12, 15)], [(7, 10), (12, 15), (17, 10)]],
    "upload": [[(4, 15), (4, 20), (20, 20), (20, 15)], [(12, 15), (12, 3.5)], [(7, 8.5), (12, 3.5), (17, 8.5)]],
    "save": [[(4, 3.5), (16.5, 3.5), (20.5, 7.5), (20.5, 20.5), (4, 20.5), (4, 3.5)],
             [(8, 3.5), (8, 8.5), (15.5, 8.5), (15.5, 3.5)], [(7.5, 20.5), (7.5, 14), (17, 14), (17, 20.5)]],
    "info": [_circle(12, 12, 9.5), [(12, 11), (12, 17)], [(12, 7.6), (12.05, 7.6)]],
    "sun": _sun(),
    "moon": _moon(),
    "folder": [[(3, 6), (9, 6), (11, 8.5), (21, 8.5), (21, 19.5), (3, 19.5), (3, 6)]],
    "undo": [_arc(12, 12.5, 8, 160, 440, 36), [(3.2, 4.4), (3.6, 9.6), (8.8, 9.2)]],
    "chart": [[(5, 20), (5, 12)], [(12, 20), (12, 4)], [(19, 20), (19, 9)], [(2.5, 20.5), (21.5, 20.5)]],
    "sliders": [[(3, 7), (21, 7)], [(3, 17), (21, 17)], _circle(9, 7, 2.6), _circle(15, 17, 2.6)],
    "activity": [[(22, 12), (18, 12), (15, 21), (9, 3), (6, 12), (2, 12)]],
    "check": [_circle(12, 12, 9.5), [(7.6, 12.4), (10.8, 15.6), (16.6, 9)]],
    "globe": [_circle(12, 12, 9.5), [(2.5, 12), (21.5, 12)], _ellipse(12, 12, 4.2, 9.5)],
    "target": [_circle(12, 12, 9.5), _circle(12, 12, 5.4), [(12, 12), (12.05, 12)]],
    "list": [[(8.5, 6), (21, 6)], [(8.5, 12), (21, 12)], [(8.5, 18), (21, 18)],
             [(3, 6), (3.05, 6)], [(3, 12), (3.05, 12)], [(3, 18), (3.05, 18)]],
}


def _segment_distance(px, py, a, b):
    ax, ay = a
    bx, by = b
    dx, dy = bx - ax, by - ay
    length2 = dx * dx + dy * dy
    if length2 < 1e-12:
        return np.hypot(px - ax, py - ay)
    t = np.clip(((px - ax) * dx + (py - ay) * dy) / length2, 0, 1)
    return np.hypot(px - (ax + t * dx), py - (ay + t * dy))


def render_icon_alpha(name, size, width=2.0):
    """Anti-aliased coverage (0..1) of an icon's strokes, as a size x size array."""
    ys, xs = np.mgrid[0:size, 0:size]
    px, py = (xs + 0.5) * 24.0 / size, (ys + 0.5) * 24.0 / size
    scale = size / 24.0
    width = max(width, 36.0 / size)      # never thinner than ~1.5 pixels, so small icons stay readable
    alpha = np.zeros((size, size))
    for poly in ICONS[name]:
        for a, b in zip(poly[:-1], poly[1:]):
            d = _segment_distance(px, py, a, b)
            alpha = np.maximum(alpha, np.clip((width / 2 - d) * scale + 0.5, 0, 1))
    return alpha


def _hex_rgb(h):
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def _png_bytes(rgba):
    """Encode an HxWx4 uint8 array as a PNG (so Tk can show it with soft, transparent edges)."""
    h, w = rgba.shape[:2]
    raw = b"".join(b"\x00" + rgba[y].tobytes() for y in range(h))

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def icon_image(master, name, color, size):
    alpha = render_icon_alpha(name, size)
    r, g, b = _hex_rgb(color)
    rgba = np.zeros((size, size, 4), dtype=np.uint8)
    rgba[..., 0], rgba[..., 1], rgba[..., 2] = r, g, b
    rgba[..., 3] = np.clip(alpha * 255 + 0.5, 0, 255).astype(np.uint8)
    return tk.PhotoImage(master=master, data=base64.b64encode(_png_bytes(rgba)).decode("ascii"))


def round_rect(cv, x0, y0, x1, y1, r, **kw):
    """A rounded rectangle on a canvas (a smoothed polygon with doubled corner points)."""
    r = max(1, min(r, (x1 - x0) // 2, (y1 - y0) // 2))
    pts = [x0 + r, y0, x0 + r, y0, x1 - r, y0, x1 - r, y0, x1, y0, x1, y0 + r, x1, y0 + r, x1, y1 - r, x1, y1 - r,
           x1, y1, x1 - r, y1, x1 - r, y1, x0 + r, y1, x0 + r, y1, x0, y1, x0, y1 - r, x0, y1 - r,
           x0, y0 + r, x0, y0 + r, x0, y0]
    return cv.create_polygon(pts, smooth=True, **kw)


def system_prefers_dark():
    """True if Windows is set to dark app mode. False elsewhere, or if it can't tell."""
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize")
        try:
            return winreg.QueryValueEx(key, "AppsUseLightTheme")[0] == 0
        finally:
            winreg.CloseKey(key)
    except Exception:
        return False


def resolve_mode(setting):
    """'light' or 'dark' for a saved theme choice of 'system', 'light' or 'dark'."""
    if setting in ("light", "dark"):
        return setting
    return "dark" if system_prefers_dark() else "light"



def current_season():
    today = datetime.date.today()
    return today.year if today.month >= 8 else today.year - 1


def loaded_seasons():
    """{season: completed_game_count} for everything stored so far."""
    try:
        conn = sqlite3.connect(DB_PATH)
        try:
            rows = conn.execute(
                "SELECT season, COUNT(*) FROM games WHERE completed = 1 GROUP BY season ORDER BY season"
            ).fetchall()
        finally:
            conn.close()
        return dict(rows)
    except sqlite3.OperationalError:
        return {}


def team_names(season):
    """Every team stored for a season, alphabetical."""
    try:
        conn = sqlite3.connect(DB_PATH)
        try:
            rows = conn.execute("SELECT school FROM teams WHERE season = ? ORDER BY school", (season,)).fetchall()
        finally:
            conn.close()
        return [r[0] for r in rows]
    except sqlite3.OperationalError:
        return []


# ---------------- Background tasks (run in a worker thread) ----------------
def task_download(seasons, force):
    conn = sqlite3.connect(DB_PATH)
    try:
        cfb_data.init_db(conn)
        cfb_stats.init_tables(conn)
        print("Loading stadium data...")
        cfb_stats.load_venues(conn)
        for s in seasons:
            if CANCEL.is_set():
                print("Cancelled.")
                break
            done = conn.execute(
                "SELECT COUNT(*) FROM games g WHERE g.season = ? AND g.completed = 1 "
                "AND EXISTS (SELECT 1 FROM team_game_stats t WHERE t.game_id = g.id)", (s,)
            ).fetchone()[0]
            if done and not force:
                print(f"{s}: already downloaded, skipping")
                continue
            print(f"Downloading {s}...")
            cfb_data.load_teams(conn, s)
            cfb_data.load_games(conn, s)
            cfb_stats.load_locations(conn, s)
            cfb_stats.load_game_stats(conn, s)
            cfb_stats.load_advanced(conn, s)
        conn.commit()
    finally:
        conn.close()
    print("Download finished.")
    return True


def task_fit():
    conn = sqlite3.connect(DB_PATH)
    try:
        models = efficiency.fit_models(conn)
        if not models:
            print("Not enough box score data yet. Download a few seasons first.")
            return None
        for name, (beta, r2, n) in models.items():
            print(f"{name.upper():<6} model: {n} games, R^2 = {r2:.2f}")
        print(f"Luck estimated for {efficiency.fill_game_luck(conn)} games")
        print("(R^2 near 1 = the stats explain margin very well. These refit automatically.)")
        return True
    finally:
        conn.close()


def task_backtest(seasons):
    print("Loading seasons...")
    datasets = backtest.load_datasets(seasons)
    print("Predicting every game from weeks 3-14 using only earlier results...")
    score = backtest.evaluate(datasets, range(3, 15))
    print("\nRESULT: " + backtest.describe(score))
    return score


def task_tune(seasons):
    print("Loading seasons...")
    datasets = backtest.load_datasets(seasons)
    params, best = backtest.tune(datasets, range(4, 15, 2))
    backtest.save_tuned(params)
    print("\nBest settings found and saved:")
    for k, v in params.items():
        print(f"  {k} = {v}")
    print("RESULT: " + backtest.describe(best))
    return best


def task_rank(season, week):
    data = ratings.load_season(season)
    return ratings.compute_ratings(data, week)


def task_check_update(url):
    print("Checking for updates...")
    try:
        manifest = updater.check_online(url)
    except updater.UpdateError as e:
        raise SystemExit(str(e))
    if manifest is None:
        print("You're on the latest version.")
        return {"up_to_date": True}
    print(f"Version {manifest['version']} is available.")
    return manifest


def task_install_update(manifest):
    try:
        return updater.download_and_install(manifest)
    except updater.UpdateError as e:
        raise SystemExit(str(e))


def task_matchup(season, home, away, neutral):
    data = ratings.load_season(season)
    _, info = ratings.compute_ratings(data, None)
    return ratings.predict_matchup(data, info, home, away, neutral)


def task_slate(season):
    data = ratings.load_season(season)
    _, info = ratings.compute_ratings(data, None)
    result = ratings.predict_upcoming(data, info)
    if result["games"]:
        ratings.log_predictions(season, result)
        print(f"Saved {len(result['games'])} predictions to the prediction log.")
    return result


def task_learn(seasons):
    backtest.learn(seasons)
    print("\n" + ratings.prediction_log_report())
    return True


# ---------------- UI plumbing ----------------
class QueueWriter:
    def __init__(self, q):
        self.q = q

    def write(self, text):
        if text:
            self.q.put(("log", text))

    def flush(self):
        pass



# ---------------- Widgets: rounded cards, icon buttons, tabs, badge, progress ----------------
# Each one takes (parent, app, ...) and has restyle(), which the app calls when the theme changes.
class Surface(tk.Frame):
    """A plain colored area (window background or card background)."""

    def __init__(self, parent, app, bg="bg", **kw):
        super().__init__(parent, bd=0, highlightthickness=0, **kw)
        self.app, self.bg_role = app, bg
        app.register(self)
        self.restyle()

    def restyle(self):
        self.configure(bg=self.app.pal[self.bg_role])


class Divider(tk.Frame):
    """A thin line (vertical or horizontal)."""

    def __init__(self, parent, app, vertical=False):
        size = {"width": max(1, S(1))} if vertical else {"height": max(1, S(1))}
        super().__init__(parent, bd=0, highlightthickness=0, **size)
        self.app = app
        app.register(self)
        self.restyle()

    def restyle(self):
        self.configure(bg=self.app.pal["card_border"])


class Lbl(tk.Label):
    """Themed text. fg/bg are palette roles; delta changes the size relative to normal text."""

    def __init__(self, parent, app, text="", fg="text", bg="card", delta=0, bold=False, **kw):
        super().__init__(parent, text=text, bd=0, highlightthickness=0, **kw)
        self.app, self.fg_role, self.bg_role, self.delta, self.bold = app, fg, bg, delta, bold
        app.register(self)
        self.restyle()

    def restyle(self):
        p = self.app.pal
        font = (FONT_FAMILY, self.app.base + self.delta) + (("bold",) if self.bold else ())
        self.configure(fg=p[self.fg_role], bg=p[self.bg_role], font=font)


class IconLabel(tk.Label):
    """An icon that recolors with the theme."""

    def __init__(self, parent, app, name, color="accent", size=22, bg="card"):
        super().__init__(parent, bd=0, highlightthickness=0)
        self.app, self.name, self.color_role, self.size, self.bg_role = app, name, color, size, bg
        app.register(self)
        self.restyle()

    def set_icon(self, name):
        self.name = name
        self.restyle()

    def restyle(self):
        p = self.app.pal
        self._img = self.app.icon(self.name, p[self.color_role], self.size)
        self.configure(image=self._img, bg=p[self.bg_role])


class Card(tk.Canvas):
    """A rounded panel. Put your widgets in `card.body`. stretch=True fills the space it is given;
    otherwise the card is exactly as tall as its contents."""

    def __init__(self, parent, app, pad=18, stretch=False, radius=14):
        super().__init__(parent, bd=0, highlightthickness=0, height=S(60))
        self.app, self.pad, self.stretch, self.radius = app, S(pad), stretch, S(radius)
        self.body = tk.Frame(self, bd=0, highlightthickness=0)
        self._win = self.create_window(self.pad, self.pad, window=self.body, anchor="nw")
        self._shape = None
        self._h = 0
        self.bind("<Configure>", self._on_canvas)
        if not stretch:
            self.body.bind("<Configure>", self._on_body)
        app.register(self)
        self.restyle()

    def restyle(self):
        p = self.app.pal
        self.configure(bg=p["bg"])
        self.body.configure(bg=p["card"])
        self._draw()

    def _draw(self):
        if self._shape is not None:
            self.delete(self._shape)
            self._shape = None
        w, h = self.winfo_width(), self.winfo_height()
        if w < 4 or h < 4:
            return
        p = self.app.pal
        self._shape = round_rect(self, 1, 1, w - 2, h - 2, self.radius, fill=p["card"], outline=p["card_border"],
                                 width=max(1, S(1)))
        self.tag_lower(self._shape)

    def _on_canvas(self, event):
        inner_w = max(1, event.width - 2 * self.pad)
        if self.stretch:
            self.itemconfigure(self._win, width=inner_w, height=max(1, event.height - 2 * self.pad))
        else:
            self.itemconfigure(self._win, width=inner_w)
        self._draw()

    def _on_body(self, event):
        h = self.body.winfo_reqheight() + 2 * self.pad
        if h != self._h:
            self._h = h
            self.configure(height=h)


class AppButton(tk.Canvas):
    """A rounded button with an optional icon. variant: 'primary' (green) or 'ghost' (neutral)."""

    def __init__(self, parent, app, text, command=None, icon=None, variant="primary", on="card",
                 min_width=0, compact=False):
        super().__init__(parent, bd=0, highlightthickness=0)
        self.app, self.text, self.command, self.icon = app, text, command, icon
        self.variant, self.on, self.min_width, self.compact = variant, on, S(min_width), compact
        self.state = "normal"
        self._hover = self._down = False
        self.bind("<Enter>", self._enter)
        self.bind("<Leave>", self._leave)
        self.bind("<ButtonPress-1>", self._press)
        self.bind("<ButtonRelease-1>", self._release)
        self.bind("<Configure>", lambda e: self.draw())
        app.register(self)
        self.draw()

    def restyle(self):
        self.draw()

    def configure(self, cnf=None, **kw):
        changed = False
        for key in ("state", "text", "command", "icon"):
            if key in kw:
                setattr(self, key, kw.pop(key))
                changed = True
        result = super().configure(cnf, **kw) if (cnf or kw) else None
        if changed:
            self.draw()
        return result

    config = configure

    def draw(self):
        p = self.app.pal
        font = (FONT_FAMILY, self.app.base, "bold" if self.variant == "primary" else "normal")
        text_w = self.app.text_width(self.text, font)
        icon_px = S(16 if self.compact else 18)
        pad_x = S(14 if self.compact else 20)
        gap = S(9)
        content_w = text_w + (icon_px + gap if self.icon else 0)
        req_w = max(self.min_width, 2 * pad_x + content_w)
        h = S(32 if self.compact else 42)
        super().configure(width=req_w, height=h, bg=p[self.on])
        self.delete("all")
        w = max(self.winfo_width(), req_w)

        disabled = self.state == "disabled"
        lit = self._hover or self._down
        if self.variant == "primary":
            fill = p["disabled_fill"] if disabled else (p["accent_hover"] if lit else p["accent_fill"])
            outline = p["card_border"] if disabled else p["accent"]
            icon_color = p["muted"] if disabled else p["accent"]
        else:
            fill = p["disabled_fill"] if disabled else (p["chip"] if lit else p["tab_fill"])
            outline = p["card_border"] if disabled else (p["accent"] if lit else p["input_border"])
            icon_color = p["muted"] if disabled else p["text"]
        text_color = p["muted"] if disabled else p["text"]
        round_rect(self, 1, 1, w - 2, h - 2, S(10), fill=fill, outline=outline, width=max(1, S(1)))
        x = (w - content_w) / 2
        if self.icon:
            self._img = self.app.icon(self.icon, icon_color, icon_px)
            self.create_image(x, h / 2, image=self._img, anchor="w")
            x += icon_px + gap
        self.create_text(x, h / 2, text=self.text, anchor="w", fill=text_color, font=font)
        super().configure(cursor="" if disabled else "hand2")

    def _enter(self, event):
        self._hover = True
        self.draw()

    def _leave(self, event):
        self._hover = self._down = False
        self.draw()

    def _press(self, event):
        if self.state != "disabled":
            self._down = True
            self.draw()

    def _release(self, event):
        clicked = self._down and self._hover
        self._down = False
        self.draw()
        if clicked and self.state != "disabled" and self.command:
            self.command()


class AppTab(tk.Canvas):
    def __init__(self, parent, app, text, icon, command):
        super().__init__(parent, bd=0, highlightthickness=0, width=S(80), cursor="hand2")
        self.app, self.text, self.icon, self.command = app, text, icon, command
        self.active = False
        self._hover = False
        self.bind("<Enter>", lambda e: self._set_hover(True))
        self.bind("<Leave>", lambda e: self._set_hover(False))
        self.bind("<ButtonRelease-1>", lambda e: self.command())
        self.bind("<Configure>", lambda e: self.draw())
        app.register(self)
        self.draw()

    def restyle(self):
        self.draw()

    def _set_hover(self, value):
        self._hover = value
        self.draw()

    def draw(self):
        p = self.app.pal
        font = (FONT_FAMILY, self.app.base, "bold" if self.active else "normal")
        h = S(46)
        self.configure(height=h, bg=p["bg"])
        self.delete("all")
        w = max(self.winfo_width(), S(80))
        fill = p["tab_active"] if self.active else (p["chip"] if self._hover else p["tab_fill"])
        outline = p["accent"] if self.active else p["card_border"]
        round_rect(self, 1, 1, w - 2, h - 2, S(10), fill=fill, outline=outline, width=max(1, S(1)))
        icon_px, gap = S(20), S(10)
        text_w = self.app.text_width(self.text, font)
        x = (w - (icon_px + gap + text_w)) / 2
        self._img = self.app.icon(self.icon, p["accent"] if self.active else p["muted"], icon_px)
        self.create_image(x, h / 2, image=self._img, anchor="w")
        self.create_text(x + icon_px + gap, h / 2, text=self.text, anchor="w", font=font,
                         fill=p["text"] if self.active else p["muted"])
        if self.active:
            self.create_line(w * 0.32, h - S(4), w * 0.68, h - S(4), fill=p["accent"], width=max(2, S(2)))


class TabBar(tk.Frame):
    def __init__(self, parent, app, on_select):
        super().__init__(parent, bd=0, highlightthickness=0)
        self.app, self.on_select = app, on_select
        self.tabs = {}
        app.register(self)
        self.restyle()

    def restyle(self):
        self.configure(bg=self.app.pal["bg"])

    def add(self, name, text, icon):
        col = len(self.tabs)
        tab = AppTab(self, self.app, text, icon, lambda n=name: self.select(n))
        tab.grid(row=0, column=col, sticky="ew", padx=(0 if col == 0 else S(8), 0))
        self.columnconfigure(col, weight=1, uniform="tabs")
        self.tabs[name] = tab

    def select(self, name):
        for key, tab in self.tabs.items():
            tab.active = key == name
            tab.draw()
        self.on_select(name)


class Badge(tk.Canvas):
    """A small status pill: a colored dot plus text."""

    COLORS = {"ok": ("accent", "accent_fill", "accent"), "bad": ("danger", "chip", "danger"),
              "warn": ("warn", "chip", "warn"), "muted": ("input_border", "chip", "muted")}

    def __init__(self, parent, app, text="", kind="muted", on="bg"):
        super().__init__(parent, bd=0, highlightthickness=0)
        self.app, self.text, self.kind, self.on = app, text, kind, on
        app.register(self)
        self.draw()

    def restyle(self):
        self.draw()

    def set(self, text, kind):
        self.text, self.kind = text, kind
        self.draw()

    def draw(self):
        p = self.app.pal
        border, fill, ink = (p[r] for r in self.COLORS[self.kind])
        font = (FONT_FAMILY, max(self.app.base - 1, 8))
        text_w = self.app.text_width(self.text, font)
        h, dot = S(28), S(8)
        w = S(14) + dot + S(8) + text_w + S(14)
        self.configure(width=w, height=h, bg=p[self.on])
        self.delete("all")
        round_rect(self, 1, 1, w - 2, h - 2, h // 2, fill=fill, outline=border, width=max(1, S(1)))
        self.create_oval(S(14), h / 2 - dot / 2, S(14) + dot, h / 2 + dot / 2, fill=ink, outline=ink)
        self.create_text(S(14) + dot + S(8), h / 2, text=self.text, anchor="w", fill=ink, font=font)


class Chip(tk.Canvas):
    """One stored season: the year in green and its game count."""

    def __init__(self, parent, app, year, games):
        super().__init__(parent, bd=0, highlightthickness=0, width=S(128), height=S(66))
        self.app, self.year, self.games = app, year, games
        app.register(self)
        self.draw()

    def restyle(self):
        self.draw()

    def draw(self):
        p = self.app.pal
        self.configure(bg=p["card"])
        self.delete("all")
        round_rect(self, 1, 1, S(128) - 2, S(66) - 2, S(10), fill=p["chip"], outline=p["card_border"], width=max(1, S(1)))
        self.create_text(S(16), S(22), text=str(self.year), anchor="w", fill=p["accent"],
                         font=(FONT_FAMILY, self.app.base, "bold"))
        self.create_text(S(16), S(44), text=f"{self.games:,} games", anchor="w", fill=p["text"],
                         font=(FONT_FAMILY, max(self.app.base - 1, 8)))


class ProgressPill(tk.Canvas):
    """A rounded progress bar. start() runs a moving segment while a job works; set(f) shows a fraction."""

    def __init__(self, parent, app):
        super().__init__(parent, bd=0, highlightthickness=0, height=S(10))
        self.app = app
        self.fraction, self.running, self.pos, self._job = 0.0, False, -0.3, None
        self.bind("<Configure>", lambda e: self.draw())
        app.register(self)
        self.draw()

    def restyle(self):
        self.draw()

    def set(self, fraction):
        self.fraction = max(0.0, min(1.0, fraction))
        self.draw()

    def start(self):
        if self.running:
            return
        self.running, self.pos = True, -0.3
        self._tick()

    def stop(self):
        self.running = False
        if self._job is not None:
            self.after_cancel(self._job)
            self._job = None
        self.fraction = 0.0
        self.draw()

    def _tick(self):
        if not self.running:
            return
        self.pos += 0.02
        if self.pos > 1.0:
            self.pos = -0.3
        self.draw()
        self._job = self.after(30, self._tick)

    def draw(self):
        p = self.app.pal
        h = S(10)
        w = max(self.winfo_width(), S(100))
        self.configure(bg=p["card"], height=h)
        self.delete("all")
        round_rect(self, 0, 0, w - 1, h - 1, h // 2, fill=p["trough"], outline=p["trough"])
        if self.running:
            x0, x1 = max(0, int(self.pos * w)), min(w - 1, int((self.pos + 0.3) * w))
        else:
            x0, x1 = 0, int(self.fraction * (w - 1))
        if x1 - x0 > h:
            round_rect(self, x0, 0, x1, h - 1, h // 2, fill=p["accent"], outline=p["accent"])


class PlaceholderEntry(ttk.Entry):
    """A text box that shows faint hint text while empty. Use value() to read it."""

    def __init__(self, parent, placeholder, mask=True):
        super().__init__(parent)
        self.placeholder, self.mask, self._showing = placeholder, mask, False
        self.bind("<FocusIn>", self._focus_in)
        self.bind("<FocusOut>", self._focus_out)
        self._show_placeholder()

    def _show_placeholder(self):
        if not self.get():
            self._showing = True
            self.configure(show="", style="Placeholder.TEntry")
            self.insert(0, self.placeholder)

    def _focus_in(self, event):
        if self._showing:
            self.delete(0, "end")
            self._showing = False
            self.configure(style="TEntry", show="\u2022" if self.mask else "")

    def _focus_out(self, event):
        if not self.get():
            self._show_placeholder()

    def set_value(self, text):
        self.delete(0, "end")
        self._showing = False
        if text:
            self.configure(style="TEntry", show="\u2022" if self.mask else "")
            self.insert(0, text)
        else:
            self._show_placeholder()

    def value(self):
        return "" if self._showing else self.get().strip()


# ---------------- The window ----------------
class App:
    PAGES = (("setup", "Setup & Data", "gear"), ("train", "Train", "dumbbell"), ("rank", "Rankings", "trophy"),
             ("match", "Matchups", "shuffle"), ("updates", "Updates", "refresh"), ("settings", "Settings", "gear"))

    def __init__(self, root):
        global UI_SCALE
        self.root = root
        try:
            UI_SCALE = max(1.0, float(root.tk.call("tk", "scaling")) / (96.0 / 72.0))
        except Exception:
            UI_SCALE = 1.0
        self.q = queue.Queue()
        self.busy = False
        self._had_error = False
        self.rows, self.rank_info, self.rank_label = [], {}, ""
        self.buttons, self.themed, self.icon_cache = [], [], {}
        self._chip_state, self._chips = None, []
        self.page_frames = {}

        s = app_config.load_settings()
        self.theme_var = tk.StringVar(value=s.get("theme", "system"))
        self.size_var = tk.StringVar(value=s.get("text_size", "default"))
        self.dpi_var = tk.BooleanVar(value=bool(s.get("sharp_display", True)))
        self._compute_theme()
        self._configure_ttk()

        root.title(f"CFB Computer Poll  v{updater.running_version()}")
        root.geometry(f"{S(1120)}x{S(840)}")
        root.minsize(S(980), S(720))
        try:
            self._window_icon = self.icon("football", self.pal["accent"], 64)
            root.iconphoto(True, self._window_icon)
        except Exception:
            pass
        self.status = tk.StringVar(value="Ready")

        self.outer = Surface(root, self)
        self.outer.pack(fill="both", expand=True, padx=S(24), pady=S(18))
        self._build_header(self.outer)
        self.tabs = TabBar(self.outer, self, self.show_page)
        self.tabs.pack(fill="x", pady=(S(16), S(14)))
        self._build_status(self.outer)                  # packed at the bottom before the pages claim the rest
        self.pages = Surface(self.outer, self)
        self.pages.pack(fill="both", expand=True)
        self.pages.grid_rowconfigure(0, weight=1)
        self.pages.grid_columnconfigure(0, weight=1)
        self._build_log(self.outer)

        builders = {"setup": self._build_setup, "train": self._build_train, "rank": self._build_rank,
                    "match": self._build_match, "updates": self._build_updates, "settings": self._build_settings}
        for name, label, icon in self.PAGES:
            page = Surface(self.pages, self)
            page.grid(row=0, column=0, sticky="nsew")
            self.page_frames[name] = page
            self.tabs.add(name, label, icon)
            builders[name](page)

        self.apply_theme()
        self.tabs.select("setup")
        self.refresh_summary()
        self.refresh_version()
        self.refresh_calibration()
        self.show_startup_notes()
        self._set_badge(None, no_key=not self.key_entry.value())
        root.after(100, self._poll)
        root.after(800, self.check_api)

    # ----- small building blocks -----
    def register(self, widget):
        self.themed.append(widget)

    def icon(self, name, color, size):
        key = (name, color, size)
        if key not in self.icon_cache:
            self.icon_cache[key] = icon_image(self.root, name, color, size)
        return self.icon_cache[key]

    def text_width(self, text, font):
        try:
            return int(self.root.tk.call("font", "measure", font, text))
        except Exception:
            return int(len(text) * self.base * 0.62)

    def btn(self, parent, text, command, icon=None, variant="primary", min_width=0, compact=False, track=True,
            on="card"):
        b = AppButton(parent, self, text, command, icon=icon, variant=variant, min_width=min_width, compact=compact,
                      on=on)
        if track:
            self.buttons.append(b)
        return b

    def card(self, parent, pad=18, stretch=False, gap=12):
        c = Card(parent, self, pad=pad, stretch=stretch)
        if stretch:
            c.pack(fill="both", expand=True, pady=(0, S(gap)))
        else:
            c.pack(fill="x", pady=(0, S(gap)))
        return c

    def row(self, parent, pady=(0, 0)):
        r = Surface(parent, self, "card")
        r.pack(fill="x", pady=pady)
        return r

    def heading(self, parent, icon, text):
        r = self.row(parent)
        IconLabel(r, self, icon, "accent", S(26)).pack(side="left", padx=(0, S(14)))
        Lbl(r, self, text, delta=3, bold=True).pack(side="left")
        return r

    def combo(self, parent, var, values, width=8, state="readonly"):
        return ttk.Combobox(parent, textvariable=var, values=values, width=width, state=state)

    def autowrap(self, label, margin=0):
        label.master.bind("<Configure>", lambda e: label.configure(wraplength=max(S(240), e.width - margin)), add="+")

    def show_page(self, name):
        self.page_frames[name].tkraise()

    # ----- header, status bar, log -----
    def _build_header(self, parent):
        hdr = Surface(parent, self)
        hdr.pack(fill="x")
        left = Surface(hdr, self)
        left.pack(side="left")
        IconLabel(left, self, "football", "accent", S(48), bg="bg").pack(side="left", padx=(0, S(16)))
        titles = Surface(left, self)
        titles.pack(side="left")
        Lbl(titles, self, "CFB Computer Poll", bg="bg", delta=12, bold=True).pack(anchor="w")
        sub = Surface(titles, self)
        sub.pack(anchor="w", pady=(S(2), 0))
        Lbl(sub, self, "Opponent-adjusted ratings for every FBS and FCS team", fg="muted", bg="bg").pack(side="left")
        self.badge = Badge(sub, self)
        self.badge.pack(side="left", padx=(S(16), 0))
        right = Surface(hdr, self)
        right.pack(side="right")
        self.theme_btn = self.btn(right, "Light mode", self.toggle_theme, icon="sun", variant="ghost",
                                  compact=True, track=False, on="bg")
        self.theme_btn.pack(anchor="e")
        Lbl(right, self, f"v{updater.running_version()}", fg="muted", bg="bg", delta=-1).pack(anchor="e", pady=(S(6), 0))

    def _build_status(self, parent):
        self.status_card = Card(parent, self, pad=14)
        self.status_card.pack(side="bottom", fill="x", pady=(S(12), 0))
        body = self.status_card.body
        top = self.row(body)
        self.status_icon = IconLabel(top, self, "check", "accent", S(22))
        self.status_icon.pack(side="left")
        Lbl(top, self, textvariable=self.status, delta=1, bold=True).pack(side="left", padx=(S(12), 0))
        self.cancel_btn = self.btn(top, "Cancel", self.cancel, variant="ghost", compact=True, track=False)
        self.cancel_btn.pack(side="right")
        self.cancel_btn.configure(state="disabled")
        self.log_btn = self.btn(top, "Show log", self.toggle_log, icon="list", variant="ghost", compact=True,
                                track=False)
        self.log_btn.pack(side="right", padx=(0, S(10)))
        self.progress = ProgressPill(body, self)
        self.progress.pack(fill="x", pady=(S(10), 0))

    def _build_log(self, parent):
        self.log_visible = False
        self.log_card = Card(parent, self, pad=10)
        self.log = scrolledtext.ScrolledText(self.log_card.body, height=9, wrap="word")
        self.log.pack(fill="both", expand=True)

    def toggle_log(self, show=None):
        show = (not self.log_visible) if show is None else show
        if show == self.log_visible:
            return
        self.log_visible = show
        if show:
            self.log_card.pack(side="bottom", fill="x", pady=(S(12), 0), before=self.pages)
        else:
            self.log_card.pack_forget()
        self.log_btn.configure(text="Hide log" if show else "Show log")

    def write_log(self, text):
        self.log.insert("end", text)
        self.log.see("end")
        if "ERROR" in text or "rolled back" in text:
            self._had_error = True
            self.toggle_log(True)

    # ----- running jobs in the background -----
    def cancel(self):
        CANCEL.set()
        self.status.set("Cancelling...")

    def run(self, label, func, on_done=None):
        if self.busy:
            return
        self.busy, self._had_error = True, False
        CANCEL.clear()
        self.status.set(label + "...")
        self.status_icon.set_icon("refresh")
        self.progress.start()
        self.cancel_btn.configure(state="normal")
        for b in self.buttons:
            b.configure(state="disabled")
        self.write_log(f"\n--- {label} ---\n")

        def worker():
            try:
                with contextlib.redirect_stdout(QueueWriter(self.q)):
                    result = func()
                self.q.put(("done", result, on_done))
            except backtest.Cancelled:
                self.q.put(("log", "\nCancelled.\n"))
                self.q.put(("done", None, None))
            except SystemExit as e:
                self.q.put(("log", f"\nERROR: {e}\n"))
                self.q.put(("done", None, None))
            except Exception as e:
                self.q.put(("log", f"\nERROR: {e}\n{traceback.format_exc()}\n"))
                self.q.put(("done", None, None))

        threading.Thread(target=worker, daemon=True).start()

    def _finish(self, result, on_done):
        self.busy = False
        self.progress.stop()
        self.status.set("Finished - see the log for errors" if self._had_error else "Ready")
        self.status_icon.set_icon("info" if self._had_error else "check")
        self.cancel_btn.configure(state="disabled")
        for b in self.buttons:
            b.configure(state="normal")
        self.refresh_summary()
        if on_done and result is not None:
            on_done(result)

    def _poll(self):
        try:
            while True:
                msg = self.q.get_nowait()
                if msg[0] == "log":
                    self.write_log(msg[1])
                elif msg[0] == "api":
                    self._set_badge(msg[1])
                elif msg[0] == "done":
                    self._finish(msg[1], msg[2])
        except queue.Empty:
            pass
        self.root.after(100, self._poll)

    # ----- API key status badge -----
    def _set_badge(self, code, no_key=False):
        if no_key:
            self.badge.set("No API key", "warn")
        elif code == 200:
            self.badge.set("API connected", "ok")
        elif code in (401, 403):
            self.badge.set("API key rejected", "bad")
        elif code == 429:
            self.badge.set("API limit reached", "warn")
        elif code is None:
            self.badge.set("Can't reach API", "muted")
        else:
            self.badge.set(f"API error {code}", "warn")

    def check_api(self):
        key = self.key_entry.value()
        if not key:
            self._set_badge(None, no_key=True)
            return
        self.badge.set("Checking API...", "muted")

        def work():
            try:
                r = requests.get(cfb_data.BASE_URL + "/conferences", timeout=10,
                                 headers={"Authorization": f"Bearer {key}", "Accept": "application/json"})
                code = r.status_code
            except Exception:
                code = None
            self.q.put(("api", code))

        threading.Thread(target=work, daemon=True).start()

    # ----- page 1: setup & data -----
    def _build_setup(self, page):
        cur = current_season()
        years = [str(y) for y in range(2004, datetime.date.today().year + 2)]

        c = self.card(page)
        self.heading(c.body, "key", "Free API key from collegefootballdata.com:")
        row = self.row(c.body, pady=(S(14), 0))
        self.save_btn = self.btn(row, "Save key", self.save_key, icon="save", min_width=150)
        self.save_btn.pack(side="right", padx=(S(14), 0))
        self.key_entry = PlaceholderEntry(row, "Paste your API key here...")
        self.key_entry.pack(side="left", fill="x", expand=True, ipady=S(8))
        self.key_entry.set_value(app_config.load_settings().get("api_key", ""))

        c = self.card(page)
        row = self.row(c.body)
        IconLabel(row, self, "calendar", "accent", S(26)).pack(side="left", padx=(0, S(14)))
        Lbl(row, self, "Historic seasons:", delta=3, bold=True).pack(side="left")
        self.hist_btn = self.btn(row, "Download missing seasons", self.download_hist, icon="download", min_width=320)
        self.hist_btn.pack(side="right")
        Divider(row, self, vertical=True).pack(side="right", fill="y", padx=S(22))
        self.hist_from, self.hist_to = tk.StringVar(value=str(cur - 5)), tk.StringVar(value=str(cur - 1))
        self.combo(row, self.hist_to, years, 7).pack(side="right")
        Lbl(row, self, "to").pack(side="right", padx=S(14))
        self.combo(row, self.hist_from, years, 7).pack(side="right")

        c = self.card(page)
        row = self.row(c.body)
        IconLabel(row, self, "calendar", "accent", S(26)).pack(side="left", padx=(0, S(14)))
        Lbl(row, self, "Current season:", delta=3, bold=True).pack(side="left")
        self.cur_var = tk.StringVar(value=str(cur))
        self.combo(row, self.cur_var, years, 7).pack(side="left", padx=(S(24), 0))
        self.cur_btn = self.btn(row, "Update current season", self.download_current, icon="refresh", min_width=320)
        self.cur_btn.pack(side="right")
        Divider(row, self, vertical=True).pack(side="right", fill="y", padx=S(22))

        c = self.card(page)
        self.heading(c.body, "database", "Stored seasons")
        self.chip_area = Surface(c.body, self, "card")
        self.chip_area.pack(fill="x", pady=(S(14), S(6)))
        self.chip_area.bind("<Configure>", lambda e: self._layout_chips())
        Divider(c.body, self).pack(fill="x", pady=(S(8), S(12)))
        info = self.row(c.body)
        IconLabel(info, self, "info", "muted", S(22)).pack(side="left", anchor="n", padx=(0, S(14)))
        self.info_lbl = Lbl(info, self, "Each season downloaded uses roughly 60 API calls, so check your monthly "
                                        "limit. Historic seasons only download once. 'Update current season' "
                                        "re-downloads the season in progress.\nYour data and settings are stored in:  "
                                        + str(app_config.APP_DIR), fg="muted", justify="left", anchor="w")
        self.info_lbl.pack(side="left", fill="x", expand=True)
        self.autowrap(self.info_lbl, S(70))

    def save_key(self):
        s = app_config.load_settings()
        s["api_key"] = self.key_entry.value()
        app_config.save_settings(s)
        self.write_log("API key saved.\n")
        self.check_api()

    def _download(self, label, seasons, force):
        if not self.key_entry.value():
            messagebox.showinfo("API key needed", "Enter your API key and press 'Save key' first.")
            return
        self.save_key()
        self.run(label, lambda: task_download(seasons, force))

    def download_hist(self):
        a, b = sorted((int(self.hist_from.get()), int(self.hist_to.get())))
        self._download("Downloading historic seasons", list(range(a, b + 1)), force=False)

    def download_current(self):
        self._download("Updating current season", [int(self.cur_var.get())], force=True)

    def refresh_chips(self, seasons):
        state = tuple(seasons.items())
        if state == self._chip_state:
            return
        self._chip_state = state
        for child in list(self.chip_area.winfo_children()):
            child.destroy()
        self._chips = []
        if not seasons:
            Lbl(self.chip_area, self, "No data downloaded yet.", fg="muted").grid(row=0, column=0, sticky="w")
            return
        for year, games in seasons.items():
            self._chips.append(Chip(self.chip_area, self, year, games))
        self._layout_chips()

    def _layout_chips(self):
        if not self._chips:
            return
        width = self.chip_area.winfo_width()
        per = max(1, width // (S(128) + S(10))) if width > 50 else 8
        for i, chip in enumerate(self._chips):
            chip.grid(row=i // per, column=i % per, padx=(0, S(10)), pady=(0, S(10)), sticky="w")

    def refresh_summary(self):
        seasons = loaded_seasons()
        self.refresh_chips(seasons)
        if hasattr(self, "season_box"):
            self.season_box["values"] = list(seasons) or [current_season()]
            if not self.season_var.get() or int(self.season_var.get()) not in seasons:
                self.season_var.set(str(max(seasons)) if seasons else "")
        if hasattr(self, "m_season_box"):
            self.m_season_box["values"] = list(seasons)
            if not self.m_season.get() or int(self.m_season.get()) not in seasons:
                self.m_season.set(str(max(seasons)) if seasons else "")
            self.load_team_names()

    # ----- page 2: train -----
    def _build_train(self, page):
        cur = current_season()
        years = [str(y) for y in range(2004, datetime.date.today().year + 2)]
        c = self.card(page)
        self.heading(c.body, "chart", "Historic training")
        desc = Lbl(c.body, self, "Historic training tests the model on past seasons: for every week it uses only "
                                 "earlier games to predict that week, then scores itself. Auto-tune then tries "
                                 "different settings (how much to trust stats, rest, travel, luck...) and keeps "
                                 "what predicts best. Do this after downloading a few seasons.",
                   fg="muted", justify="left", anchor="w")
        desc.pack(fill="x", pady=(S(10), 0))
        self.autowrap(desc, 0)
        row = self.row(c.body, pady=(S(18), 0))
        Lbl(row, self, "Train on seasons:", bold=True).pack(side="left")
        self.tr_from, self.tr_to = tk.StringVar(value=str(cur - 5)), tk.StringVar(value=str(cur - 1))
        self.combo(row, self.tr_from, years, 7).pack(side="left", padx=(S(14), 0))
        Lbl(row, self, "to").pack(side="left", padx=S(12))
        self.combo(row, self.tr_to, years, 7).pack(side="left")
        row = self.row(c.body, pady=(S(18), 0))
        self.btn(row, "Run backtest", self.run_backtest, icon="chart").pack(side="left", padx=(0, S(10)))
        self.btn(row, "Auto-tune settings (slow)", self.run_tune, icon="sliders", variant="ghost").pack(
            side="left", padx=(0, S(10)))
        self.btn(row, "Check efficiency models", lambda: self.run("Checking efficiency models", task_fit),
                 icon="activity", variant="ghost").pack(side="left", padx=(0, S(10)))
        self.btn(row, "Reset to defaults", self.reset, icon="undo", variant="ghost").pack(side="left")
        self.train_result = tk.StringVar()
        res = Lbl(c.body, self, textvariable=self.train_result, fg="accent", justify="left", anchor="w")
        res.pack(fill="x", pady=(S(16), 0))

    def _train_seasons(self):
        a, b = sorted((int(self.tr_from.get()), int(self.tr_to.get())))
        return list(range(a, b + 1))

    def run_backtest(self):
        seasons = self._train_seasons()
        self.run("Backtesting", lambda: task_backtest(seasons),
                 lambda s: self.train_result.set("Backtest: " + backtest.describe(s)))

    def run_tune(self):
        seasons = self._train_seasons()
        self.run("Auto-tuning", lambda: task_tune(seasons),
                 lambda s: self.train_result.set("Tuned settings saved. " + backtest.describe(s)))

    def reset(self):
        backtest.reset_defaults()
        self.train_result.set("Settings reset to defaults.")
        self.write_log("Settings reset to defaults.\n")

    # ----- page 3: rankings -----
    def _build_rank(self, page):
        c = self.card(page, pad=16)
        row = self.row(c.body)
        Lbl(row, self, "Season:", bold=True).pack(side="left")
        self.season_var = tk.StringVar()
        self.season_box = ttk.Combobox(row, textvariable=self.season_var, width=7, state="readonly")
        self.season_box.pack(side="left", padx=(S(10), S(22)))
        Lbl(row, self, "Through week:", bold=True).pack(side="left")
        self.week_var = tk.StringVar(value="Latest")
        self.combo(row, self.week_var, ["Latest"] + [str(w) for w in range(1, 16)], 8).pack(
            side="left", padx=(S(10), S(22)))
        Lbl(row, self, "Show:", bold=True).pack(side="left")
        self.div_var = tk.StringVar(value="All")
        div_box = self.combo(row, self.div_var, ["All", "FBS", "FCS"], 6)
        div_box.pack(side="left", padx=(S(10), 0))
        div_box.bind("<<ComboboxSelected>>", lambda e: self.show_table())
        self.btn(row, "Export CSV", self.export, icon="download", variant="ghost").pack(side="right")
        self.btn(row, "Generate rankings", self.generate, icon="trophy").pack(side="right", padx=(0, S(10)))

        t = self.card(page, pad=12, stretch=True, gap=0)
        self.rank_note = tk.StringVar()
        Lbl(t.body, self, textvariable=self.rank_note, fg="muted", anchor="w").pack(side="bottom", fill="x",
                                                                                   pady=(S(8), 0))
        frame = Surface(t.body, self, "card")
        frame.pack(fill="both", expand=True)
        cols = ("rank", "team", "rating", "division", "conference", "home")
        heads = ("#", "Team", "Rating", "Div", "Conference", "Home edge")
        widths = (60, 260, 90, 70, 230, 100)
        self.tree = ttk.Treeview(frame, columns=cols, show="headings")
        for col, head, width in zip(cols, heads, widths):
            self.tree.heading(col, text=head)
            self.tree.column(col, width=S(width), anchor="w" if col in ("team", "conference") else "center")
        sb = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

    def generate(self):
        if not self.season_var.get():
            messagebox.showinfo("No data", "Download at least one season on the Setup tab first.")
            return
        season = int(self.season_var.get())
        week = None if self.week_var.get() == "Latest" else int(self.week_var.get())
        self.rank_label = f"{season}" + (f"_wk{week}" if week else "")
        self.run("Computing rankings", lambda: task_rank(season, week), self.on_ranked)

    def on_ranked(self, result):
        self.rows, self.rank_info = result
        self.show_table()
        self.write_log(ratings.summary_line(self.rank_info) + "\n")

    def visible_rows(self):
        d = self.div_var.get()
        return [r for r in self.rows if d == "All" or r[2].upper() == d]

    def show_table(self):
        self.tree.delete(*self.tree.get_children())
        for rank, (team, rating, div, conf, hfa) in enumerate(self.visible_rows(), 1):
            self.tree.insert("", "end", tags=("odd" if rank % 2 == 0 else "even",),
                             values=(rank, team, f"{rating:.1f}", div.upper(), conf, f"{hfa:.1f}"))
        if self.rank_info:
            self.rank_note.set(ratings.summary_line(self.rank_info))

    def export(self):
        rows = self.visible_rows()
        if not rows:
            messagebox.showinfo("Nothing to export", "Generate rankings first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv", initialfile=f"rankings_{self.rank_label or 'poll'}.csv",
            filetypes=[("CSV file", "*.csv")])
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["rank", "team", "rating", "division", "conference", "home_field_edge"])
            for rank, (team, rating, div, conf, hfa) in enumerate(rows, 1):
                w.writerow([rank, team, f"{rating:.2f}", div, conf, f"{hfa:.2f}"])
        self.write_log(f"Exported {len(rows)} teams to {path}\n")

    # ----- page 4: matchups -----
    def _build_match(self, page):
        c = self.card(page, pad=16)
        row = self.row(c.body)
        Lbl(row, self, "Season:", bold=True).pack(side="left")
        self.m_season = tk.StringVar()
        self.m_season_box = ttk.Combobox(row, textvariable=self.m_season, width=7, state="readonly")
        self.m_season_box.pack(side="left", padx=(S(10), S(20)))
        self.m_season_box.bind("<<ComboboxSelected>>", lambda e: self.load_team_names())
        Lbl(row, self, "Home team:", bold=True).pack(side="left")
        self.m_home = tk.StringVar()
        self.m_home_box = ttk.Combobox(row, textvariable=self.m_home, width=18)
        self.m_home_box.pack(side="left", padx=(S(10), S(20)))
        Lbl(row, self, "Visitor:", bold=True).pack(side="left")
        self.m_away = tk.StringVar()
        self.m_away_box = ttk.Combobox(row, textvariable=self.m_away, width=18)
        self.m_away_box.pack(side="left", padx=(S(10), S(20)))
        self.m_neutral = tk.BooleanVar(value=False)
        ttk.Checkbutton(row, text="Neutral site", variable=self.m_neutral, style="Card.TCheckbutton").pack(side="left")
        self.btn(row, "Predict", self.predict_matchup, icon="target", min_width=130).pack(side="right")

        r = self.card(page)
        self.m_result = tk.StringVar(value="Pick two teams (you can type part of a name) and press Predict.")
        Lbl(r.body, self, textvariable=self.m_result, delta=6, bold=True, justify="left", anchor="w").pack(fill="x")
        self.m_detail = tk.StringVar()
        detail = Lbl(r.body, self, textvariable=self.m_detail, fg="muted", justify="left", anchor="w")
        detail.pack(fill="x", pady=(S(6), 0))
        self.autowrap(detail, 0)

        t = self.card(page, pad=14, stretch=True, gap=0)
        top = self.row(t.body)
        self.btn(top, "Predict next games", self.predict_slate, icon="calendar").pack(side="left")
        self.btn(top, "Learn from results", self.learn, icon="activity", variant="ghost").pack(
            side="left", padx=(S(10), S(16)))
        self.m_cal = tk.StringVar()
        Lbl(top, self, textvariable=self.m_cal, fg="muted").pack(side="left")
        self.m_note = tk.StringVar()
        Lbl(t.body, self, textvariable=self.m_note, fg="muted", anchor="w", justify="left").pack(
            side="bottom", fill="x", pady=(S(8), 0))
        frame = Surface(t.body, self, "card")
        frame.pack(fill="both", expand=True, pady=(S(12), 0))
        cols = ("date", "home", "away", "pick", "margin", "prob")
        heads = ("Date", "Home", "Visitor", "Pick", "By", "Win chance")
        widths = (100, 220, 220, 220, 70, 110)
        self.m_tree = ttk.Treeview(frame, columns=cols, show="headings")
        for col, head, width in zip(cols, heads, widths):
            self.m_tree.heading(col, text=head)
            self.m_tree.column(col, width=S(width), anchor="w" if col in ("home", "away", "pick") else "center")
        sb = ttk.Scrollbar(frame, orient="vertical", command=self.m_tree.yview)
        self.m_tree.configure(yscrollcommand=sb.set)
        self.m_tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

    def load_team_names(self):
        if not self.m_season.get():
            return
        names = team_names(int(self.m_season.get()))
        self.m_home_box["values"] = names
        self.m_away_box["values"] = names

    def refresh_calibration(self):
        self.m_cal.set(ratings.calibration_text())

    @staticmethod
    def _resolve_team(text, names):
        t = text.strip().lower()
        if not t:
            return None
        exact = [n for n in names if n.lower() == t]
        if exact:
            return exact[0]
        for test in (lambda n: n.lower().startswith(t), lambda n: t in n.lower()):
            found = [n for n in names if test(n)]
            if len(found) == 1:
                return found[0]
        return None

    def predict_matchup(self):
        if not self.m_season.get():
            messagebox.showinfo("No data", "Download at least one season on the Setup tab first.")
            return
        season = int(self.m_season.get())
        names = team_names(season)
        home = self._resolve_team(self.m_home.get(), names)
        away = self._resolve_team(self.m_away.get(), names)
        if not home or not away:
            messagebox.showinfo("Pick teams", "Couldn't match one of the team names. Pick from the "
                                              "dropdown, or type enough of the name to be unique.")
            return
        neutral = bool(self.m_neutral.get())
        self.run("Predicting matchup", lambda: task_matchup(season, home, away, neutral), self.show_matchup)

    def show_matchup(self, res):
        home_fav = res["margin"] >= 0
        fav = res["home"] if home_fav else res["away"]
        prob = res["home_win_prob"] if home_fav else 1 - res["home_win_prob"]
        site = "at a neutral site" if res["neutral"] else f"at {res['home']}"
        self.m_result.set(f"{fav} by {abs(res['margin']):.1f}   ({prob * 100:.0f}% to win)")
        self.m_detail.set(
            f"{res['away']} vs {res['home']}, {site}. Rough projected score: {res['home']} "
            f"{res['home_points']:.0f}, {res['away']} {res['away_points']:.0f}. A typical miss on a game "
            f"like this is about {res['sigma']:.0f} points either way. "
            f"Ratings: {res['home']} {res['home_rating']:.1f}, {res['away']} {res['away_rating']:.1f}.")

    def predict_slate(self):
        if not self.m_season.get():
            messagebox.showinfo("No data", "Download at least one season on the Setup tab first.")
            return
        season = int(self.m_season.get())
        self.run("Predicting next games", lambda: task_slate(season), self.show_slate)

    def show_slate(self, result):
        self.m_tree.delete(*self.m_tree.get_children())
        for i, g in enumerate(result["games"]):
            home_fav = g["margin"] >= 0
            fav = g["home"] if home_fav else g["away"]
            prob = g["home_win_prob"] if home_fav else 1 - g["home_win_prob"]
            self.m_tree.insert("", "end", tags=("odd" if i % 2 else "even",),
                               values=(g["date"], g["home"], g["away"], fav,
                                       f"{abs(g['margin']):.1f}", f"{prob * 100:.0f}%"))
        if result["games"]:
            note = f"Week {result['week']}: {len(result['games'])} games predicted"
            if result["skipped"]:
                note += f" ({result['skipped']} skipped - a team has no rated games yet)"
            note += ". Saved to the prediction log so they can be scored once results arrive."
        else:
            note = "No unplayed games found. Use 'Update current season' on the Setup tab to pull the schedule."
        self.m_note.set(note)

    def learn(self):
        seasons = list(loaded_seasons())
        if not seasons:
            messagebox.showinfo("No data", "Download at least one season on the Setup tab first.")
            return
        self.run("Learning from results", lambda: task_learn(seasons), lambda r: self.refresh_calibration())

    # ----- page 5: updates -----
    def _build_updates(self, page):
        c = self.card(page)
        self.ver_var = tk.StringVar()
        r = self.heading(c.body, "refresh", "Program updates")
        Lbl(c.body, self, textvariable=self.ver_var, delta=1, bold=True, anchor="w").pack(fill="x", pady=(S(10), 0))
        desc = Lbl(c.body, self, "Updates change the program without rebuilding the .exe. When you get an update "
                                 "package (a .zip), install it here and restart. Updates can change how the poll "
                                 "works, but they can't add new libraries or change the launcher - those need a "
                                 "one-time rebuild with build_exe.bat. If an update ever fails to start, the program "
                                 "goes back to a working version by itself.",
                   fg="muted", justify="left", anchor="w")
        desc.pack(fill="x", pady=(S(8), 0))
        self.autowrap(desc, 0)
        row = self.row(c.body, pady=(S(16), 0))
        self.btn(row, "Install update from file...", self.install_from_file, icon="upload").pack(side="left")

        c = self.card(page)
        self.heading(c.body, "globe", "Online updates (optional)")
        row = self.row(c.body, pady=(S(14), 0))
        self.btn(row, "Check online for updates", self.check_online, icon="refresh", variant="ghost").pack(
            side="right", padx=(S(14), 0))
        self.url_var = tk.StringVar(value=app_config.load_settings().get("update_url", ""))
        ttk.Entry(row, textvariable=self.url_var).pack(side="left", fill="x", expand=True, ipady=S(8))
        note = Lbl(c.body, self, "The address of the manifest.json file you host (for example on GitHub). "
                                 "An update is code that runs on your computer, so only use an address you control.",
                   fg="muted", justify="left", anchor="w")
        note.pack(fill="x", pady=(S(10), 0))
        self.autowrap(note, 0)

        c = self.card(page)
        self.heading(c.body, "undo", "Go back")
        row = self.row(c.body, pady=(S(14), 0))
        self.btn(row, "Undo last update", self.undo_update, icon="undo", variant="ghost").pack(side="left", padx=(0, S(10)))
        self.btn(row, "Revert to built-in version", self.revert, icon="undo", variant="ghost").pack(side="left")

    def refresh_version(self):
        running, installed = updater.running_version(), updater.installed_version()
        text = f"Running version {running}"
        if installed != running:
            text += f"   (version {installed} is installed - restart to use it)"
        self.ver_var.set(text)

    def show_startup_notes(self):
        err = updater.pop_startup_error()
        if err:
            self.write_log("The last update could not start and was rolled back to a working version:\n"
                           + err + "\n")

    def restart_prompt(self, manifest):
        self.refresh_version()
        self.write_log(f"Version {manifest['version']} installed.\n")
        if messagebox.askyesno("Update installed",
                               f"Version {manifest['version']} is installed. Restart now to use it?"):
            updater.relaunch()
            self.root.destroy()

    def install_from_file(self):
        path = filedialog.askopenfilename(title="Choose an update package", filetypes=[("Update package", "*.zip")])
        if not path:
            return
        try:
            manifest = updater.install_file(path)
        except updater.UpdateError as e:
            messagebox.showerror("Update not installed", str(e))
            return
        self.restart_prompt(manifest)

    def check_online(self):
        url = self.url_var.get().strip()
        if not url:
            messagebox.showinfo("Update address needed", "Paste the https:// address of your manifest.json first.")
            return
        s = app_config.load_settings()
        s["update_url"] = url
        app_config.save_settings(s)
        self.run("Checking for updates", lambda: task_check_update(url), self.offer_update)

    def offer_update(self, manifest):
        if manifest.get("up_to_date"):
            return
        notes = manifest.get("notes", "")
        if messagebox.askyesno("Update available",
                               f"Version {manifest['version']} is available.\n\n{notes}\n\nDownload and install it now?"):
            self.run("Installing update", lambda: task_install_update(manifest), self.restart_prompt)

    def undo_update(self):
        if not updater.undo_last_update():
            messagebox.showinfo("Nothing to undo", "There is no previous update to go back to.")
            return
        self.refresh_version()
        if messagebox.askyesno("Update undone", f"Switched to version {updater.installed_version()}. "
                                                "Restart now to use it?"):
            updater.relaunch()
            self.root.destroy()

    def revert(self):
        if not messagebox.askyesno("Revert", "Remove all installed updates and go back to the version "
                                             "built into the .exe?"):
            return
        updater.revert_to_builtin()
        self.refresh_version()
        if messagebox.askyesno("Reverted", "Restart now to use the built-in version?"):
            updater.relaunch()
            self.root.destroy()

    # ----- page 6: settings -----
    def _build_settings(self, page):
        c = self.card(page)
        self.heading(c.body, "gear", "Appearance")
        for label, var, options in (("Theme", self.theme_var, (("Match Windows", "system"), ("Light", "light"),
                                                                ("Dark", "dark"))),
                                    ("Text size", self.size_var, (("Small", "small"), ("Default", "default"),
                                                                  ("Large", "large")))):
            row = self.row(c.body, pady=(S(14), 0))
            Lbl(row, self, label, bold=True, anchor="w").pack(side="left")
            box = Surface(row, self, "card")
            box.pack(side="left", padx=(S(30), 0))
            for text, value in options:
                ttk.Radiobutton(box, text=text, value=value, variable=var, style="Card.TRadiobutton",
                                command=self.on_appearance_change).pack(side="left", padx=(0, S(22)))
        row = self.row(c.body, pady=(S(14), 0))
        ttk.Checkbutton(row, text="Sharp text and icons on high-resolution screens (restart to apply)",
                        variable=self.dpi_var, style="Card.TCheckbutton", command=self.on_dpi_change).pack(side="left")

        c = self.card(page)
        self.heading(c.body, "database", "Data")
        Lbl(c.body, self, "Your downloaded data and settings are stored in:", anchor="w").pack(
            fill="x", pady=(S(12), 0))
        Lbl(c.body, self, str(app_config.APP_DIR), fg="muted", anchor="w").pack(fill="x")
        row = self.row(c.body, pady=(S(14), 0))
        self.btn(row, "Open data folder", self.open_data_folder, icon="folder", variant="ghost").pack(side="left")

        c = self.card(page)
        self.heading(c.body, "info", "About")
        Lbl(c.body, self, f"CFB Computer Poll  -  version {updater.running_version()}  -  "
                          f"core v{updater.BASE_VERSION}", anchor="w").pack(fill="x", pady=(S(12), 0))
        Lbl(c.body, self, "More settings will appear here as the program grows.", fg="muted", anchor="w").pack(
            fill="x", pady=(S(4), 0))

    def on_appearance_change(self):
        s = app_config.load_settings()
        s["theme"] = self.theme_var.get()
        s["text_size"] = self.size_var.get()
        app_config.save_settings(s)
        self.apply_theme()

    def on_dpi_change(self):
        s = app_config.load_settings()
        s["sharp_display"] = bool(self.dpi_var.get())
        app_config.save_settings(s)
        messagebox.showinfo("Restart needed", "Close and reopen the program to apply this change.")

    def toggle_theme(self):
        self.theme_var.set("light" if self.mode == "dark" else "dark")
        self.on_appearance_change()

    def open_data_folder(self):
        path = str(app_config.APP_DIR)
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception:
            messagebox.showinfo("Data folder", f"Your files are in:\n{path}")

    # ----- theme -----
    @staticmethod
    def _walk(widget):
        yield widget
        for child in widget.winfo_children():
            yield from App._walk(child)

    def _titlebar(self, dark):
        """Make the Windows title bar match the theme (best effort; harmless if unsupported)."""
        if sys.platform != "win32":
            return
        try:
            import ctypes
            self.root.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(self.root.winfo_id())
            value = ctypes.c_int(1 if dark else 0)
            for attr in (20, 19):    # 20 on current Windows 10/11, 19 on early Windows 10 builds
                if ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(value),
                                                              ctypes.sizeof(value)) == 0:
                    break
        except Exception:
            pass

    def _compute_theme(self):
        self.mode = resolve_mode(self.theme_var.get())
        self.pal = PALETTES[self.mode]
        self.base = TEXT_SIZES.get(self.size_var.get(), 10)

    def _configure_ttk(self):
        p, base, root = self.pal, self.base, self.root
        for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont", "TkCaptionFont", "TkTooltipFont"):
            try:     # set via Tcl so we don't need Python's tkinter.font module (not always bundled)
                root.tk.call("font", "configure", name, "-family", FONT_FAMILY, "-size", base)
            except Exception:
                pass
        st = ttk.Style()
        try:
            st.theme_use("clam")      # the one built-in theme that honors custom colors everywhere
        except tk.TclError:
            pass
        root.configure(bg=p["bg"])
        st.configure(".", background=p["bg"], foreground=p["text"], fieldbackground=p["input"],
                     bordercolor=p["input_border"], lightcolor=p["input_border"], darkcolor=p["input_border"],
                     troughcolor=p["input"], focuscolor=p["accent"], insertcolor=p["text"])
        st.configure("TFrame", background=p["bg"])
        for w in ("TEntry", "TCombobox", "TSpinbox"):
            st.configure(w, fieldbackground=p["input"], background=p["tab_fill"], foreground=p["text"],
                         bordercolor=p["input_border"], lightcolor=p["input_border"], darkcolor=p["input_border"],
                         arrowcolor=p["text"], insertcolor=p["text"], padding=S(6), arrowsize=S(16))
        st.configure("Placeholder.TEntry", foreground=p["muted"])
        st.map("TEntry", bordercolor=[("focus", p["accent"])], lightcolor=[("focus", p["accent"])],
               darkcolor=[("focus", p["accent"])])
        st.map("TCombobox", fieldbackground=[("readonly", p["input"])], foreground=[("readonly", p["text"])],
               selectbackground=[("readonly", p["input"])], selectforeground=[("readonly", p["text"])],
               bordercolor=[("focus", p["accent"])])
        for w in ("Card.TRadiobutton", "Card.TCheckbutton"):
            st.configure(w, background=p["card"], foreground=p["text"], indicatorbackground=p["input"],
                         indicatorforeground=p["accent"], focuscolor=p["card"])
            st.map(w, background=[("active", p["card"])],
                   indicatorbackground=[("selected", p["accent_fill"]), ("pressed", p["accent_fill"])],
                   indicatorforeground=[("selected", p["accent"])])
        st.configure("Treeview", background=p["card"], fieldbackground=p["card"], foreground=p["text"],
                     bordercolor=p["card"], lightcolor=p["card"], darkcolor=p["card"],
                     rowheight=int(base * 2.7 * UI_SCALE), borderwidth=0)
        st.map("Treeview", background=[("selected", p["select"])], foreground=[("selected", p["select_text"])])
        st.configure("Treeview.Heading", background=p["tab_fill"], foreground=p["muted"], relief="flat",
                     borderwidth=0, padding=(S(10), S(8)), font=(FONT_FAMILY, base, "bold"))
        st.map("Treeview.Heading", background=[("active", p["chip"])])
        st.configure("TScrollbar", background=p["tab_fill"], troughcolor=p["card"], bordercolor=p["card"],
                     arrowcolor=p["muted"], relief="flat", arrowsize=S(14))
        st.map("TScrollbar", background=[("active", p["input_border"])])
        # Dropdown lists of comboboxes are separate windows with their own colors.
        for opt, key in (("background", "input"), ("foreground", "text"),
                         ("selectBackground", "select"), ("selectForeground", "select_text")):
            root.option_add(f"*TCombobox*Listbox.{opt}", p[key])
        for w in self._walk(root):
            if w.winfo_class() == "TCombobox":
                try:
                    pop = root.tk.call("ttk::combobox::PopdownWindow", str(w))
                    root.tk.call(f"{pop}.f.l", "configure", "-background", p["input"], "-foreground", p["text"],
                                 "-selectbackground", p["select"], "-selectforeground", p["select_text"])
                except Exception:
                    pass

    def restyle_all(self):
        for w in list(self.themed):
            try:
                if not w.winfo_exists():
                    self.themed.remove(w)
                    continue
                w.restyle()
            except tk.TclError:
                self.themed.remove(w)

    def _restyle_plain(self):
        p, base = self.pal, self.base
        self.log.configure(bg=p["log_bg"], fg=p["text"], insertbackground=p["text"], selectbackground=p["select"],
                           selectforeground=p["select_text"], relief="flat", borderwidth=0, highlightthickness=0,
                           padx=S(10), pady=S(8), font=("Consolas", max(base - 1, 8)))
        for tree in (self.tree, self.m_tree):
            tree.tag_configure("odd", background=p["odd"])
            tree.tag_configure("even", background=p["card"])
        dark = self.mode == "dark"
        self.theme_btn.configure(text="Light mode" if dark else "Dark mode", icon="sun" if dark else "moon")

    def apply_theme(self):
        self._compute_theme()
        self._configure_ttk()
        self.restyle_all()
        self._restyle_plain()
        self._titlebar(self.mode == "dark")


def main():
    s = app_config.load_settings()
    if s.get("sharp_display", True) and sys.platform == "win32":
        try:
            import ctypes
            try:
                ctypes.windll.shcore.SetProcessDpiAwareness(1)    # crisp text; must happen before the window exists
            except Exception:
                ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
